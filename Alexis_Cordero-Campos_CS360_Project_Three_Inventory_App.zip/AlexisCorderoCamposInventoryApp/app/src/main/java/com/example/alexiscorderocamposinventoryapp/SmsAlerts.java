package com.example.alexiscorderocamposinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

/** Send an SMS only when permission and a destination number are configured. */
public final class SmsAlerts {
    private SmsAlerts() { }
    public static void sendIfLow(Context context, String product, int quantity) {
        if (quantity > 0 || ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) return;
        String number = context.getSharedPreferences("sms_settings", Context.MODE_PRIVATE).getString("number", "").trim();
        if (number.isEmpty()) return;
        try {
            SmsManager manager = context.getSystemService(SmsManager.class);
            if (manager != null) manager.sendTextMessage(number, null,
                    "Inventory alert: " + product + " is out of stock (quantity 0).", null, null);
        } catch (Exception e) {
            Toast.makeText(context, "SMS could not be sent", Toast.LENGTH_SHORT).show();
        }
    }
}
