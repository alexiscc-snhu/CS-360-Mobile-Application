package com.example.alexiscorderocamposinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private long owner;
    private LinearLayout rows;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_inventory);
        owner = getIntent().getLongExtra("owner_id", -1);
        if (owner < 0) { finish(); return; }
        db = new DatabaseHelper(this); rows = findViewById(R.id.inventoryRows);
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent); finish();
        });
        findViewById(R.id.btnAddItem).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddItemActivity.class); intent.putExtra("owner_id", owner); startActivity(intent);
        });
        findViewById(R.id.btnSmsSettings).setOnClickListener(v -> startActivity(new Intent(this, SmsPermissionActivity.class)));
    }
    @Override protected void onResume() { super.onResume(); if (rows != null) refresh(); }
    private int dp(int size) { return (int)(size * getResources().getDisplayMetrics().density + .5f); }
    private TextView cell(String value, float weight) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(Color.rgb(17,24,39));
        t.setTextSize(14); t.setGravity(Gravity.CENTER_VERTICAL);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), weight)); return t;
    }
    private Button action(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(0,0,0,0);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));
        return b;
    }
    private void refresh() {
        rows.removeAllViews();
        try (Cursor c = db.getItems(owner)) {
            if (c.getCount() == 0) { TextView empty = cell("No inventory items yet. Tap Add Item.", 1); rows.addView(empty); return; }
            while (c.moveToNext()) {
                long id = c.getLong(0); String name = c.getString(1); int quantity = c.getInt(2);
                LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.setPadding(dp(6), dp(5), dp(6), dp(5));
                TextView product = cell(name, 2); line.addView(product);
                TextView count = cell(String.valueOf(quantity), 1); count.setGravity(Gravity.CENTER); line.addView(count);
                LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
                actions.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 2));
                Button minus = action("−"), plus = action("+"), delete = action("×");
                minus.setOnClickListener(v -> change(id, name, Math.max(0, quantity - 1)));
                plus.setOnClickListener(v -> { if (quantity < Integer.MAX_VALUE) change(id, name, quantity + 1); });
                delete.setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setMessage("Delete " + name + "?")
                        .setPositiveButton("Delete", (dialog, which) -> { db.deleteItem(owner, id); refresh(); })
                        .setNegativeButton("Cancel", null).show());
                actions.addView(minus); actions.addView(plus); actions.addView(delete);
                line.addView(actions); rows.addView(line);
                View separator = new View(this); separator.setBackgroundColor(Color.rgb(229,231,235));
                rows.addView(separator, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        }
    }
    private void change(long id, String name, int quantity) {
        if (db.setQuantity(owner, id, quantity) > 0) {
            SmsAlerts.sendIfLow(this, name, quantity); refresh();
        }
    }
}
