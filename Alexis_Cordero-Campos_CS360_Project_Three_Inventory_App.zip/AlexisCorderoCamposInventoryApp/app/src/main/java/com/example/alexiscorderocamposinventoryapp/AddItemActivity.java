package com.example.alexiscorderocamposinventoryapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_add_item);
        long owner = getIntent().getLongExtra("owner_id", -1);
        if (owner < 0) { finish(); return; }
        EditText name = findViewById(R.id.etProductName), qty = findViewById(R.id.etStartingQuantity);
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            String product = name.getText().toString().trim(), amount = qty.getText().toString().trim();
            int count;
            try { count = Integer.parseInt(amount); } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid quantity", Toast.LENGTH_SHORT).show(); return;
            }
            if (product.isEmpty() || count < 0) { Toast.makeText(this, "Enter a name and nonnegative quantity", Toast.LENGTH_SHORT).show(); return; }
            DatabaseHelper db = new DatabaseHelper(this);
            long id = db.addItem(owner, product, count);
            if (id < 0) { Toast.makeText(this, "Could not save item", Toast.LENGTH_SHORT).show(); return; }
            SmsAlerts.sendIfLow(this, product, count);
            finish();
        });
        findViewById(R.id.btnCancel).setOnClickListener(v -> finish());
    }
}
