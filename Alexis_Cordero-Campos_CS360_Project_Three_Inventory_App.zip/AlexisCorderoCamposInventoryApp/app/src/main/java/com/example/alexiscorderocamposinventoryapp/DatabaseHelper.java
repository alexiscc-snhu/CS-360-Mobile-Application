package com.example.alexiscorderocamposinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;

/** Persistent storage for accounts and inventory. No demo rows are inserted. */
public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) { super(context, "inventory.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, password_hash TEXT NOT NULL)");
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format(java.util.Locale.US, "%02x", b & 255));
        return sb.toString();
    }
    private static String hash(String salt, String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return hex(digest.digest((salt + password).getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    public boolean createAccount(String username, String password) {
        byte[] random = new byte[16]; new SecureRandom().nextBytes(random);
        String salt = hex(random);
        ContentValues values = new ContentValues();
        values.put("username", username); values.put("salt", salt);
        values.put("password_hash", hash(salt, password));
        return getWritableDatabase().insertWithOnConflict("users", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1;
    }
    public long login(String username, String password) {
        try (Cursor c = getReadableDatabase().query("users", new String[]{"id", "salt", "password_hash"},
                "username=?", new String[]{username}, null, null, null)) {
            if (c.moveToFirst() && MessageDigest.isEqual(hash(c.getString(1), password).getBytes(StandardCharsets.UTF_8),
                    c.getString(2).getBytes(StandardCharsets.UTF_8))) return c.getLong(0);
        }
        return -1;
    }
    public Cursor getItems(long owner) {
        return getReadableDatabase().query("inventory", new String[]{"id", "name", "quantity"},
                "owner_id=?", new String[]{String.valueOf(owner)}, null, null, "name COLLATE NOCASE");
    }
    public long addItem(long owner, String name, int quantity) {
        ContentValues v = new ContentValues(); v.put("owner_id", owner); v.put("name", name); v.put("quantity", quantity);
        return getWritableDatabase().insert("inventory", null, v);
    }
    public int setQuantity(long owner, long id, int quantity) {
        ContentValues v = new ContentValues(); v.put("quantity", quantity);
        return getWritableDatabase().update("inventory", v, "id=? AND owner_id=?", new String[]{String.valueOf(id), String.valueOf(owner)});
    }
    public int deleteItem(long owner, long id) {
        return getWritableDatabase().delete("inventory", "id=? AND owner_id=?", new String[]{String.valueOf(id), String.valueOf(owner)});
    }
}
