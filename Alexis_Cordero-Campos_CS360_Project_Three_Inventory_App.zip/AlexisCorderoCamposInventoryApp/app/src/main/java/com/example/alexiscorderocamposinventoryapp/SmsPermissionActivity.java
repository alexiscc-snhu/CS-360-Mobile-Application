package com.example.alexiscorderocamposinventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        status = findViewById(R.id.tvPermissionStatus);
        EditText number = findViewById(R.id.etSmsNumber);
        number.setText(getSharedPreferences("sms_settings", MODE_PRIVATE).getString("number", ""));
        findViewById(R.id.btnSaveSmsNumber).setOnClickListener(v -> {
            String value = number.getText().toString().trim();
            if (!value.matches("[+0-9() .-]{3,20}")) {
                Toast.makeText(this, "Enter a valid SMS number", Toast.LENGTH_SHORT).show(); return;
            }
            getSharedPreferences("sms_settings", MODE_PRIVATE).edit().putString("number", value).apply();
            Toast.makeText(this, "SMS destination saved", Toast.LENGTH_SHORT).show();
        });
        Button enable = findViewById(R.id.btnEnableSms);
        Button notNow = findViewById(R.id.btnNotNow);
        Button back = findViewById(R.id.btnBackToInventory);
        updatePermissionStatusDisplay();
        enable.setOnClickListener(v -> requestSmsPermission());
        notNow.setOnClickListener(v -> finish());
        back.setOnClickListener(v -> finish());
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) updatePermissionStatusDisplay();
    }

    private void updatePermissionStatusDisplay() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        status.setText(granted ? R.string.status_permission_granted : R.string.status_permission_denied);
        status.setTextColor(ContextCompat.getColor(this,
                granted ? android.R.color.holo_green_dark : android.R.color.holo_red_dark));
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            updatePermissionStatusDisplay();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,
            @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) updatePermissionStatusDisplay();
    }
}
