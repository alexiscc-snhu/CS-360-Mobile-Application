package com.example.alexiscorderocamposinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper database;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_main);
        database = new DatabaseHelper(this);
        EditText username = findViewById(R.id.etUsername);
        EditText password = findViewById(R.id.etPassword);
        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            long id = database.login(username.getText().toString().trim(), password.getText().toString());
            if (id < 0) { Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show(); return; }
            openInventory(id);
        });
        findViewById(R.id.btnCreateAccount).setOnClickListener(v -> {
            String user = username.getText().toString().trim(), pass = password.getText().toString();
            if (user.isEmpty() || pass.length() < 6) {
                Toast.makeText(this, "Enter a username and password of at least 6 characters", Toast.LENGTH_LONG).show(); return;
            }
            if (!database.createAccount(user, pass)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show(); return;
            }
            openInventory(database.login(user, pass));
        });
    }
    private void openInventory(long id) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra("owner_id", id); startActivity(intent);
    }
}
